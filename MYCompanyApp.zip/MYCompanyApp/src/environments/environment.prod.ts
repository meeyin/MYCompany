export const environment = {
  production: true,
  apiBaseUrl:"https://localhost:7186/"

};
