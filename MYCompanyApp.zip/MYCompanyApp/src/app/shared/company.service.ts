import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http'
import { environment } from 'src/environments/environment';
import { Company, Industry } from './company.model';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  url:string=environment.apiBaseUrl + 'company/list'
  companyUrl:string=environment.apiBaseUrl + 'company'
  list: Company[]=[];
  formSubmitted: boolean = false;
  formData: Company = new Company()
  constructor(private http: HttpClient) { }
  refreshList(){
    
    this.http.get(this.url)
    .subscribe({
      next: res=>{
        this.list = res as Company[];
      },
      error: err => {console.log(err)}
    })
  }

  getIndustryList() {
    // Assuming your API endpoint for industry list is 'industry/list'
    const industryUrl = environment.apiBaseUrl + 'data/industry';

    return this.http.get<Industry[]>(industryUrl);
  }

  getData(pageSize: number, pageIndex: number, sortField: string, sortOrder: string, search: string): Observable<any> {
    console.log(pageSize);
    let params = new HttpParams()
      .set('pageSize', pageSize.toString())
      .set('pageIndex', pageIndex.toString())
      .set('sortField', sortField)
      .set('sortOrder', sortOrder)
      .set('search', search);

    return this.http.get(this.url, { params });
  }

  getCompanyList() {
    // Assuming your API endpoint for industry list is 'industry/list'
    const companyUrl = environment.apiBaseUrl + 'company/active-list';

    return this.http.get<Company[]>(companyUrl);
  }

  postCompany(){
    if (this.formData.parentCompanyId === '') {
      this.formData.parentCompanyId = null;
    }
    return this.http.post(this.companyUrl,this.formData)
  }

  putCompany(){
    if (this.formData.parentCompanyId === '') {
      this.formData.parentCompanyId = null;
    }
    return this.http.put(this.companyUrl,this.formData)
  }

  resetForm(form:NgForm){
    form.form.reset();
    this.formData= new Company();
    this.formSubmitted = false;

  }

  
}
