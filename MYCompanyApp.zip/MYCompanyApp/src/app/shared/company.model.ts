export class Company {

    companyId: number=0;
    companyName :string ="";
    industry: string= "";
    noOfEmployee: number =0;
    city: string ="";
    parentCompanyId: string | null = null;
    industryName: string= "";
    parentCompanyName: string= "";
    level: number = 0;


}

export class Industry {
    industryTypeId :string ="";
    industryTypeDescription: string= "";
}