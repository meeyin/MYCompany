import { Component, OnInit,Renderer2, ElementRef, AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import { CompanyService } from '../shared/company.service';
import { Company, Industry } from '../shared/company.model';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';


@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements AfterViewInit, OnDestroy, OnInit {
  @ViewChild(DataTableDirective, { static: false })
  dataTable!: DataTableDirective;
  selectedOption: string | null = null; 
  selectedIndustry: string | null = null; 
  industries: Industry[] = [];
  isModalOpen = false;
  isIconHovered: boolean = false;
  title = 'datatables';
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  searchText: string = '';
  data: any[] = [];
  isDataEmpty: boolean = false;
  url:string=environment.apiBaseUrl + 'company/list'
  constructor(public service: CompanyService,private router: Router,
    private renderer: Renderer2, private el: ElementRef, private http: HttpClient) { 

  }


  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
  
  ngOnInit(): void {

    this.populateIndustryList();
    this.initializeDataTable();
  }

  
  ngAfterViewInit(): void {
    this.dtTrigger.next("");
  }

  initializeDataTable(): void {
    this.dtOptions = {
      pagingType: 'full_numbers',
      serverSide: true,
      processing: true,
      lengthMenu: [5, 10, 20, 50],
      dom: 'lrtip',
      ajax: (dataTablesParameters: any, callback: any) => {
        const customizedParams = this.customizeDataTablesParameters(dataTablesParameters);
        this.http.get(this.url, { params:  customizedParams})
        .subscribe((response: any) => {
          callback({
            recordsTotal: response.totalRecords,
            recordsFiltered: response.totalRecords,
            data: [],
          });

          this.data = response.data;
          this.isDataEmpty = this.data.length === 0
          this.dtOptions.language={zeroRecords : this.isDataEmpty ? 'No companies found' : ''};

        });
           
      },
      columns: [
        { data: 'companyId' ,orderable: false},
        { data: 'companyName' ,orderable: true},
        { data: 'industry' ,orderable: false},
        { data: 'noOfEmployee' ,orderable: false},
        { data: 'city' ,orderable: false},
        { data: 'parentCompanyId' ,orderable: false}

      ],
      order: [
        [1, 'asc']  // Adjust column index and direction as needed
      ]
    };

  }


  

  rerender(): void {
    this.dataTable.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
       dtInstance.destroy();
       this.data=[];
      
       this.initializeDataTable();
       this.dtTrigger.next("");
    });
  }

  reset(): void {
    this.dataTable.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
       dtInstance.destroy();
       this.data=[];
       this.selectedOption=null;
       this.selectedIndustry="";
       this.searchText="";
      
       this.initializeDataTable();
       this.dtTrigger.next("");
    });
  }
  


  updateDataTable(): void {
    console.log("Updating DataTable");
  
    // Check if dataTable is defined before accessing settings
    if (this.dataTable?.dtInstance) {
      // Customize dataTablesParameters based on your needs
      const customizedParams = this.customizeDataTablesParameters({});
      customizedParams.option = 1;  // Set your desired option value
  
      // Update the AJAX data parameter
      this.dataTable.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.ajax.url(this.url).load(
          customizedParams,
          false  // Set a boolean value (false) as the second parameter
        );
      });
  
    }
  }

  

  populateForm(selectorRecord:Company){
    this.service.formData= Object.assign({},selectorRecord);
    this.router.navigate(['/management/update-company']);
  }

  changeIconColor(iconId: string) {
    document.getElementById(iconId)?.classList.add('icon-blue');
  }

  resetIconColor(iconId: string) {
    document.getElementById(iconId)?.classList.remove('icon-blue');
  }

  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  populateIndustryList() {
    this.service.getIndustryList().subscribe({
      next: (industryList: Industry[]) => {
        this.industries = industryList;
      },
      error: (error) => {
        console.error('Error fetching industry list:', error);
      }
    });
  }

// Custom function to dynamically customize dataTablesParameters
customizeDataTablesParameters(dataTablesParameters: any): any {
  // Additional customization logic if needed
  dataTablesParameters.searchParam= this.selectedOption;

 if(this.selectedOption==="3")
  {
    dataTablesParameters.searchValue = this.selectedIndustry;
  }
  else
  {
    dataTablesParameters.searchValue = this.searchText;
  }

  const order = this.dtOptions.order as Array<(number | string)> | Array<Array<(number | string)>> | undefined;
  if (order) {
    if (Array.isArray(order[0])) {
        const order1 = order[0] as Array<(number | string)>;
        dataTablesParameters.ColumnSorting=order1[0];
        dataTablesParameters.Ordering=order1[1];
    }
  }
  else{
    console.log("error at customize data table param");
  }
  return dataTablesParameters;
}


}

