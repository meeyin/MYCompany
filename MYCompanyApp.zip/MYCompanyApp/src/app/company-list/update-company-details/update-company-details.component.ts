import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-update-company-details',
  templateUrl: './update-company-details.component.html',
  styleUrls: ['./update-company-details.component.css']
})
export class UpdateCompanyDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
