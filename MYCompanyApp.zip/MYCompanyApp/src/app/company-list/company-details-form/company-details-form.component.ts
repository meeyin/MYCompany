import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Company, Industry } from 'src/app/shared/company.model';
import { CompanyService } from 'src/app/shared/company.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-company-details-form',
  templateUrl: './company-details-form.component.html',
  styleUrls: ['./company-details-form.component.css']
})
export class CompanyDetailsFormComponent implements OnInit {
  industries: Industry[] = [];
  companyList: Company[] = [];

  constructor(public service : CompanyService, private toastr:ToastrService, private router: Router) { }

  ngOnInit(): void {
    this.populateIndustryList();
    this.populateCompanyDetails();
   
  }

  populateIndustryList() {
    this.service.getIndustryList().subscribe({
      next: (industryList: Industry[]) => {
        this.industries = industryList;
      },
      error: (error) => {
        console.error('Error fetching industry list:', error);
      }
    });
  }


  populateCompanyDetails(){
    this.service.getCompanyList().subscribe({
      next: (companyList: Company[]) => {
        // Exclude the current company ID if it exists
        if (this.service.formData.companyId !== 0) {
          this.companyList = companyList.filter(company => company.companyId !== this.service.formData.companyId);
        } else {
          this.companyList = companyList;
        }
      },
      error: (error) => {
        console.error('Error fetching company list:', error);
      }
    });
  }


  onSubmit(form:NgForm){
    this.service.formSubmitted = true;
    if(form.valid)
    {
        if(this.service.formData.companyId==0)
        {
          this.insertCompany(form);
        }
        else{
          this.updateCompany(form);
        }
    }
    
  }

  insertCompany(form:NgForm){
    this.service.postCompany().subscribe({
      next: res=>{
        this.service.resetForm(form);
        this.toastr.success("Inserted successfully","Company Registration");
        this.router.navigate(['/management/company']);
      },
      error:err=>{
        console.log(err)
        this.toastr.error(err.error,"Error")
      }
    })

  }

  updateCompany(form:NgForm){
    this.service.putCompany().subscribe({
      next: res=>{
        this.service.resetForm(form);
        this.toastr.success("Update successfully","Company Update");
        this.router.navigate(['/management/company']);

      },
      error:err=>{
        console.log(err)
        this.toastr.error(err.error,"Error")
      }
    })
  }
}
