import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Company } from 'src/app/shared/company.model';
import { CompanyService } from 'src/app/shared/company.service';

@Component({
  selector: 'app-add-company-details',
  templateUrl: './add-company-details.component.html',
  styleUrls: ['./add-company-details.component.css']
})
export class AddCompanyDetailsComponent implements OnInit {

  
  constructor(public service : CompanyService) { }

  ngOnInit(): void {
    this.service.formData=new Company();
  }

  @Output() closeModal = new EventEmitter<void>();

  onClose() {
    this.closeModal.emit();
  }

  

}
