import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyListComponent } from "./company-list/company-list.component";
import { CompanyDetailsFormComponent } from './company-list/company-details-form/company-details-form.component';
import { AddCompanyDetailsComponent } from './company-list/add-company-details/add-company-details.component';
import { UpdateCompanyDetailsComponent } from './company-list/update-company-details/update-company-details.component';

const routes: Routes =[
    {
        path: 'management/company',
        component: CompanyListComponent
    },
    {
        path: 'management/add-company',
        component: AddCompanyDetailsComponent
    },
    {
        path: 'management/update-company',
        component: UpdateCompanyDetailsComponent
    }


]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })

export class AppRoutingModule{

}
