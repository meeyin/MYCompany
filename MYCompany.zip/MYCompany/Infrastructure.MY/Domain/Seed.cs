﻿using Domain.MY;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.MY.Domain
{
    public static class ModelBuilderExtension
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<IndustryType>().HasData(
                IndustryType.CreateSeedData(1, "Meat processing", true),
                IndustryType.CreateSeedData(2, "Gardening and landscaping", true),
                IndustryType.CreateSeedData(3, "IT services", true),
                IndustryType.CreateSeedData(4, "Aerospace technology", true),
                IndustryType.CreateSeedData(5, "Consumer electronics", true)


            );
        }
    }
}
