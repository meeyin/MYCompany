﻿using Domain.MY;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.MY.Domain
{
    internal class CompanyEntityTypeConfiguration : IEntityTypeConfiguration<Company>
    {
        public void Configure(EntityTypeBuilder<Company> builder)
        {
            builder.ToTable(nameof(Company),"dbo");
            builder.HasKey(b => b.CompanyId);

            builder.Property(x => x.CompanyName).HasMaxLength(50);
            builder.Property(x => x.City).HasMaxLength(50);
            builder.HasOne<Company>().WithMany().HasForeignKey(p => p.ParentCompanyId);

        }
    }
}
