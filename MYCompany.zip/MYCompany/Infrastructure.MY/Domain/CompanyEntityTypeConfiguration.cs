﻿using Domain.MY;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.MY.Domain
{
    internal class IndustryEntityTypeConfiguration : IEntityTypeConfiguration<IndustryType>
    {
        public void Configure(EntityTypeBuilder<IndustryType> builder)
        {
            builder.ToTable(nameof(IndustryType),"meta");
            builder.HasKey(b => b.IndustryTypeId);

            builder.Property(x => x.IndustryTypeDescription).HasMaxLength(200);

        }
    }
}
