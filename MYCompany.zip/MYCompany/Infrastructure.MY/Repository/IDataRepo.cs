﻿using Domain.MY;
using Domain.MY.Repository;
using Infrastructure.MY;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.MY.Repository
{
    public class DataRepo : IDataRepo
    {
        private readonly MYDbContext _context;
        public DataRepo(MYDbContext context)
        {
            _context = context;
        }

        public async Task<List<IndustryType>> GetAllIndustryAsync()
        {
            return await _context.IndustryType.Where(x => x.IsActive).ToListAsync();    
        }

        public IndustryType GetIndustryById(int industryId)
        {
            return _context.IndustryType.Where(x => x.IsActive && x.IndustryTypeId==industryId).FirstOrDefault();

        }
    }
}
