﻿using Domain.MY;
using Domain.MY.Repository;
using Infrastructure.MY;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.MY.Repository
{
    public class CompanyRepo : ICompanyRepo
    {
        private readonly MYDbContext _context;
        public CompanyRepo(MYDbContext context)
        {
            _context = context;
        }
        public async Task AddAsync(Company details)
        {
            await _context.AddAsync(details);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Company details)
        {
            _context.Remove(details);
            await _context.SaveChangesAsync();

        }

        public async Task<List<Company>> GetAllAsync()
        {
            return await _context.Company.Where(x => x.IsActive).ToListAsync();
        }

        public async Task<Company> GetByIdAsync(long companyId)
        {
            return await _context.Company.Where(x => x.IsActive && x.CompanyId == companyId).FirstOrDefaultAsync();
        }

        public async Task Update(Company details)
        {
            _context.Update(details);
            await _context.SaveChangesAsync();
        }
    }
}
