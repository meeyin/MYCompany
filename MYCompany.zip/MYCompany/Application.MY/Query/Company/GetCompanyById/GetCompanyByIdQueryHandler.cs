﻿using AutoMapper;
using CSharpFunctionalExtensions;
using Domain.MY.Repository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetCompanyByIdQueryHandler : IRequestHandler<GetCompanyByIdQuery, Result<GetCompanyRespDto>>
    {
        private readonly ICompanyRepo _companyRepo;
        private readonly IMapper _mapper;

        public GetCompanyByIdQueryHandler(ICompanyRepo companyRepo, IMapper mapper)
        {
            _companyRepo = companyRepo;
            _mapper = mapper;
        }

        public async Task<Result<GetCompanyRespDto>> Handle(GetCompanyByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var company = await _companyRepo.GetByIdAsync(request.CompanyId);

                if (company != null)
                {
                    var resp = _mapper.Map<GetCompanyRespDto>(company);
                    return Result.Success(resp);
                }

                return Result.Failure<GetCompanyRespDto>("CompanyId not found");

            }
            catch (Exception ex)
            {
                return Result.Failure<GetCompanyRespDto>(ex.Message);
            }
        }
    }

}
