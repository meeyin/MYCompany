﻿using CSharpFunctionalExtensions;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetCompanyByIdQuery : IRequest<Result<GetCompanyRespDto>>
    {
        public long CompanyId { get; }


        public GetCompanyByIdQuery(long companyId)
        {
            CompanyId = companyId;

        }
    }
}
