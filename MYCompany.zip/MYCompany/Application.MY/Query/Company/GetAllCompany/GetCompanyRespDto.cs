﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetCompanyRespDto
    {
        public long CompanyId { get; set; }
        public string CompanyName { get; set; }
        public int Industry { get; set; }
        public int NoOfEmployee { get; set; }
        public string City { get; set; }
        public long? ParentCompanyId { get; set; }
        public int TotalCount { get; set; }
        public string IndustryName { get; set; }
        public string ParentCompanyName { get; set; }
        public int Level { get; set; }

    }
}
