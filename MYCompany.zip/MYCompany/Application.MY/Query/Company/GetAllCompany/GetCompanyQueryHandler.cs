﻿using AutoMapper;
using CSharpFunctionalExtensions;
using Dapper;
using Domain.MY;
using Domain.MY.Repository;
using Infrastructure.MY.Database;
using MediatR;
using Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetCompanyQueryHandler : IRequestHandler<GetCompanyQuery, Result<PagedResults<List<GetCompanyRespDto>>>>
    {
        private readonly ISqlConnectionFactory _connection;
        private readonly IMapper _mapper;

        public GetCompanyQueryHandler(ISqlConnectionFactory connection, IMapper mapper)
        {
            _connection = connection;
            _mapper = mapper;
        }

        public async Task<Result<PagedResults<List<GetCompanyRespDto>>>> Handle(GetCompanyQuery request, CancellationToken cancellationToken)
        {
            try
            {
                using (var connection = _connection.GetOpenConnection())
                {
                    string filter = "";
                    #region Search/Filter
                    if (request.SearchParam.HasValue && !string.IsNullOrEmpty(request.SearchValue))
                    {
                        switch (request.SearchParam.Value)
                        {
                            case MerchantListingSearchParam.CompanyId:
                                filter += $"cast(a.CompanyId as nvarchar(20)) = '{request.SearchValue}'";
                                break;

                            case MerchantListingSearchParam.CompanyName:
                                filter += $"a.CompanyName LIKE '%{request.SearchValue}%'";
                                break;

                            case MerchantListingSearchParam.Industry:
                                filter += $"a.Industry ={request.SearchValue}";
                                break;

                            case MerchantListingSearchParam.City:
                                filter += $"a.City LIKE '%{request.SearchValue}%'";
                                break;

                            case MerchantListingSearchParam.ParentCompany:
                                filter += $"b.CompanyName LIKE '%{request.SearchValue}%'";
                                break;

                        }
                    }
                    #endregion

                    filter = !string.IsNullOrEmpty(filter) ? " And " + filter : " ";

                    var sql = @$"
                                   WITH RecursiveCTE AS (
                                     SELECT CompanyId,ParentCompanyId,0 AS Level
                                     FROM dbo.Company
                                     WHERE ParentCompanyId IS NULL
                                     
                                     UNION ALL
  
                                     SELECT t.CompanyId,t.ParentCompanyId,r.Level + 1 AS Level
                                     FROM dbo.Company t
                                     JOIN RecursiveCTE r ON t.ParentCompanyId = r.CompanyId
                                   )

                                   select a.CompanyId, a.CompanyName, a.Industry, c.IndustryTypeDescription as 'IndustryName', a.NoOfEmployee, 
                                   a.City, a.ParentCompanyId, b.CompanyName as 'ParentCompanyName', COUNT(1)over() AS TotalCount,d.level
                                   from dbo.Company a
                                   left join dbo.Company b on (a.ParentCompanyId=b.CompanyId)
                                   inner join meta.IndustryType c on (c.IndustryTypeId=a.Industry)
                                   left join RecursiveCTE d on (d.CompanyId=a.CompanyId)
                                   where a.IsActive=1 {filter}   
                                ";

                    #region sort
                    string orderBy = @"
                            ORDER BY CASE WHEN @SortBy = 'COMPANYNAME ASC' THEN A.COMPANYNAME END ASC, 
							CASE WHEN @SortBy = 'COMPANYNAME DESC' THEN A.COMPANYNAME END DESC,
                            CASE WHEN @SortBy = '' THEN  A.COMPANYNAME END ASC
							OFFSET @Skip ROWS FETCH NEXT @Take ROWS ONLY; ";
                    #endregion


                    sql = sql + orderBy;

                    #region Paging/Sorting

                    var skip = request.Start;
                    var take = request.Length ==0 ? 5: request.Length;
                    var sortingBy = request.ColumnSorting?.ToString().ToUpper() +" "+ request.Ordering?.ToUpper();

                    #endregion

                    var result = await connection.QueryMultipleAsync(sql,new { @Skip= skip, @Take=take, @SortBy= sortingBy });

                    var respData = await result.ReadAsync<GetCompanyRespDto>();
                    var data = respData?.Count() > 0 ? respData.ToList() : new List<GetCompanyRespDto>();
                    
                    var totalRecord = respData?.Count() > 0 ? respData.FirstOrDefault().TotalCount : 0;

                    var pagedResults = new PagedResults<List<GetCompanyRespDto>>(data, totalRecord, skip / take, take);

                    //return Result.Success(pagedResults);

                    return Result.Success(pagedResults);

                }


            }
            catch(Exception ex)
            {
                return Result.Failure<PagedResults<List<GetCompanyRespDto>>> (ex.Message);
            }
        }
    }

}
