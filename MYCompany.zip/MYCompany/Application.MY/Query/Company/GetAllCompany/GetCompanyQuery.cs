﻿using CSharpFunctionalExtensions;
using Domain.MY;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetCompanyQuery : IRequest<Result<PagedResults<List<GetCompanyRespDto>>>>
    {
        public int Start { get;  }
        public int Length { get; }
        public MerchantListingSorting? ColumnSorting { get;  }
        public string Ordering { get;  }
        public MerchantListingSearchParam? SearchParam { get; }
        public string SearchValue { get; }

        public GetCompanyQuery(int start, int length, MerchantListingSorting? columnSorting, string ordering, MerchantListingSearchParam? searchParam,
                               string searchValue)
        {
            Start = start;
            Length = length;    
            ColumnSorting = columnSorting;  
            Ordering = ordering;
            SearchParam = searchParam;
            SearchValue = searchValue;
                
        }
    }
}
