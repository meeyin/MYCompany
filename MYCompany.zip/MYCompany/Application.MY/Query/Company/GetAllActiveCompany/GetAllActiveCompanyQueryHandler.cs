﻿using AutoMapper;
using CSharpFunctionalExtensions;
using Dapper;
using Domain.MY;
using Domain.MY.Repository;
using Infrastructure.MY.Database;
using MediatR;
using Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetAllActiveCompanyQueryHandler : IRequestHandler<GetAllActiveCompanyQuery, Result<List<GetAllActiveCompanyRespDto>>>
    {
        private readonly ICompanyRepo _companyRepo;
        private readonly IMapper _mapper;

        public GetAllActiveCompanyQueryHandler(ICompanyRepo companyRepo, IMapper mapper)
        {
            _companyRepo = companyRepo;
            _mapper = mapper;
        }

        public async Task<Result<List<GetAllActiveCompanyRespDto>>> Handle(GetAllActiveCompanyQuery request, CancellationToken cancellationToken)
        {
            try
            {

                var list =await _companyRepo.GetAllAsync();
                list=list.OrderBy(x => x.CompanyName).ToList();
                var resp=_mapper.Map<List<GetAllActiveCompanyRespDto>>(list);

                return Result.Success(resp);


            }
            catch(Exception ex)
            {
                return Result.Failure<List<GetAllActiveCompanyRespDto>> (ex.Message);
            }
        }
    }

}
