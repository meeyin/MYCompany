﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetAllActiveCompanyRespDto
    {
        public long companyId { get; set; }
        public string companyName { get; set; }
    }
}
