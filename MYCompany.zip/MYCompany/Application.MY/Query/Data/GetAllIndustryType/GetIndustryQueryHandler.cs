﻿using AutoMapper;
using CSharpFunctionalExtensions;
using Domain.MY.Repository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetIndustryQueryHandler : IRequestHandler<GetIndustryQuery, Result<List<GetIndustryRespDto>>>
    {
        private readonly IDataRepo _dataRepository;
        private readonly IMapper _mapper;

        public GetIndustryQueryHandler(IDataRepo dataRepository, IMapper mapper)
        {
            _dataRepository = dataRepository;
            _mapper = mapper;
        }

        public async Task<Result<List<GetIndustryRespDto>>> Handle(GetIndustryQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var list = await _dataRepository.GetAllIndustryAsync();
                var resp= _mapper.Map<List<GetIndustryRespDto>>(list);

                return Result.Success(resp);

            }
            catch(Exception ex)
            {
                return Result.Failure<List<GetIndustryRespDto>>(ex.Message);
            }
        }
    }

}
