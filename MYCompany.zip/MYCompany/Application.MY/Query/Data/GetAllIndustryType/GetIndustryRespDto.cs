﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetIndustryRespDto
    {
        public int IndustryTypeId { get; set; }
        public string IndustryTypeDescription { get; set; }
     

    }
}
