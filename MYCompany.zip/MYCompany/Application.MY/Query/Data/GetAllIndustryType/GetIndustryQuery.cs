﻿using CSharpFunctionalExtensions;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Query.Company
{
    public class GetIndustryQuery : IRequest<Result<List<GetIndustryRespDto>>>
    {

    }
}
