﻿using Dapper;
using Domain.MY;
using Domain.MY.Repository;
using Infrastructure.MY.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.DomainService
{
    public class CompanyChecker : ICompanyChecker
    {
        private readonly ISqlConnectionFactory _sqlConnectionFactory;
        private readonly IDataRepo _dataRepo;


        public CompanyChecker(ISqlConnectionFactory sqlConnectionFactory, IDataRepo dataRepo)
        {
            _sqlConnectionFactory = sqlConnectionFactory;
            _dataRepo = dataRepo;
        }

        public bool IsIndustryValid(int industryId)
        {
            var industry = _dataRepo.GetIndustryById(industryId);

            return industry != null ;
            
        }

        public bool IsParentCompanyValid(long? companyId)
        {
            if (companyId == null) 
                return true;

            using (var connection = _sqlConnectionFactory.GetOpenConnection())
            {
                string sql = $"Select top 1 1 from dbo.Company where companyId = @companyId and IsActive=1";

                var result = connection.QuerySingleOrDefault<int?>(sql, new
                {
                    CompanyId = companyId

                });


                return result.HasValue;
            }


        }

        public bool IsValidCompanyName(string companyName, long companyId)
        {
            using (var connection = _sqlConnectionFactory.GetOpenConnection())
            {
                string sql = $"Select top 1 1 from dbo.Company where companyName = @companyName and companyId != @companyId";

                var result = connection.QuerySingleOrDefault<int?>(sql, new
                {
                    CompanyName = companyName,
                    CompanyId= companyId

                });
               

                return !result.HasValue;
            }
        }
    }
}
