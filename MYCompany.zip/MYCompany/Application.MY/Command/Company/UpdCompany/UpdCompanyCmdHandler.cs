﻿using CSharpFunctionalExtensions;
using Domain.MY;
using Domain.MY.Repository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Command.Company
{
    public class UpdCompanyCmdHandler : IRequestHandler<UpdCompanyCmd, Result<bool>>
    {
        private readonly ICompanyRepo _companyRepository;
        private readonly ICompanyChecker _companyChecker;

        public UpdCompanyCmdHandler(ICompanyRepo companyRepository, ICompanyChecker companyChecker)
        {
            _companyRepository = companyRepository;
            _companyChecker = companyChecker;
        }

        public async Task<Result<bool>> Handle(UpdCompanyCmd request, CancellationToken cancellationToken)
        {
            try
            {
                var company = await _companyRepository.GetByIdAsync(request.CompanyId);

                if (company != null && company.IsActive)
                {
                    //can move to business rule
                    #region Validation 
                    var nameChecker = _companyChecker.IsValidCompanyName(request.CompanyName, request.CompanyId);

                    if (!nameChecker)
                    {
                        return Result.Failure<bool>("Please ensure the company name is unique");
                    }

                    if(request.CompanyId == request.ParentCompanyId)
                    {
                        return Result.Failure<bool>("Parent companyId and company Id cannot be same");
                    }

                    if (request.ParentCompanyId != null)
                    {
                        var parentIdChecker = _companyChecker.IsParentCompanyValid(request.ParentCompanyId);

                        if (!parentIdChecker)
                        {
                            return Result.Failure<bool>("Please ensure the parant company Id is valid");
                        }

                    }

                    var industryChecker = _companyChecker.IsIndustryValid(request.Industry);
                    if (!industryChecker)
                    {
                        return Result.Failure<bool>("Invalid industry Id");
                    }


                    #endregion



                    company.Update(request.CompanyName, request.Industry, request.NoOfEmployee, request.City, request.ParentCompanyId);
                    await _companyRepository.Update(company);

                    return true;

                }
                else
                {
                    return Result.Failure<bool>("User Id not found");
                }
                
            }
            catch(Exception ex)
            {
                return Result.Failure<bool>(ex.Message);
            }
        }
    }
}
