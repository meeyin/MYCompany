﻿using CSharpFunctionalExtensions;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Command.Company
{
    public class DeleteCompanyCmd : IRequest<Result<bool>>
    {
        public long CompanyId { get; }
       

        public DeleteCompanyCmd(long companyId)
        {
            CompanyId = companyId;

        }
    }
}
