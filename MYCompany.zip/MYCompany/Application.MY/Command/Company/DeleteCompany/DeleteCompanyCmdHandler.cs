﻿using CSharpFunctionalExtensions;
using Domain.MY.Repository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Command.Company
{
    public class DeleteCompanyCmdHandler : IRequestHandler<DeleteCompanyCmd, Result<bool>>
    {
        private readonly ICompanyRepo _companyRepository;

        public DeleteCompanyCmdHandler(ICompanyRepo companyRepository)
        {
            _companyRepository = companyRepository;
        }

        public async Task<Result<bool>> Handle(DeleteCompanyCmd request, CancellationToken cancellationToken)
        {
            try
            {
                var company = await _companyRepository.GetByIdAsync(request.CompanyId);

                if (company != null && company.IsActive)
                {
                    company.Remove();
                    await _companyRepository.Update(company);

                    return true;
                }
                else
                {
                    return Result.Failure<bool>("User Id not found");
                }
                
            }
            catch(Exception ex)
            {
                return Result.Failure<bool>(ex.Message);
            }
        }
    }
}
