﻿using CSharpFunctionalExtensions;
using Domain.MY;
using Domain.MY.Repository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Command.Company
{
    public class AddCompanyCmdHandler : IRequestHandler<AddCompanyCmd, Result<bool>>
    {
        private readonly ICompanyRepo _companyRepository;
        private readonly ICompanyChecker _companyChecker;

        public AddCompanyCmdHandler(ICompanyRepo companyRepository, ICompanyChecker companyChecker)
        {
            _companyRepository = companyRepository;
            _companyChecker = companyChecker;
        }

        public async Task<Result<bool>> Handle(AddCompanyCmd request, CancellationToken cancellationToken)
        {
            try
            {

                //encourage set companyChecker as business rule
                #region Validation
                var nameChecker = _companyChecker.IsValidCompanyName(request.CompanyName, 0);

                if (!nameChecker)
                {
                    return Result.Failure<bool>("Please ensure the company name is unique");
                }

                if (request.ParentCompanyId != null)
                {
                    var parentIdChecker = _companyChecker.IsParentCompanyValid(request.ParentCompanyId);

                    if (!parentIdChecker)
                    {
                        return Result.Failure<bool>("Please ensure the parant company Id is valid");
                    }

                }

                var industryChecker = _companyChecker.IsIndustryValid(request.Industry);
                if (!industryChecker)
                {
                    return Result.Failure<bool>("Invalid industry Id");
                }
                #endregion

                var company = Domain.MY.Company.AddCompany(request.CompanyName, request.Industry, request.NoOfEmployee, request.City, request.ParentCompanyId);

                await _companyRepository.AddAsync(company);
                return true;

            }
            catch(Exception ex)
            {
                return Result.Failure<bool>(ex.Message);
            }
        }
    }
}
