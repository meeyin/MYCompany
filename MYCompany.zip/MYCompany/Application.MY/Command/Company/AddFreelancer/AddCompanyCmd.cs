﻿using CSharpFunctionalExtensions;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MY.Command.Company
{
    public class AddCompanyCmd : IRequest<Result<bool>>
    {
        public string CompanyName { get;  }
        public int Industry { get;  }
        public int NoOfEmployee { get;  }
        public string City { get;  }
        public long? ParentCompanyId { get; }


        public AddCompanyCmd(string companyName, int industry, int noOfEmployee, string city, long? parentCompanyId)
        {
            CompanyName = companyName;
            Industry = industry;
            NoOfEmployee = noOfEmployee;
            City = city;
            ParentCompanyId = parentCompanyId;
        }
    }
}
