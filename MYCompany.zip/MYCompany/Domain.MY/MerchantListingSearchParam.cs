﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MY
{
    public enum MerchantListingSearchParam
    {
        CompanyId=1,
        CompanyName=2,
        Industry=3,
        City=4,
        ParentCompany=5

    }

    public enum MerchantListingSorting
    {
        CompanyName = 1,

    }
}
