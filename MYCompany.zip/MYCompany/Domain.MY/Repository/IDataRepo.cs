﻿namespace Domain.MY.Repository
{
    public interface IDataRepo
    {
        
        Task<List<IndustryType>> GetAllIndustryAsync();
        IndustryType GetIndustryById (int industryId);
       
    }
}
