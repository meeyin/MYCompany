﻿namespace Domain.MY.Repository
{
    public interface ICompanyRepo
    {
        Task<Company> GetByIdAsync(long companyId);
        Task<List<Company>> GetAllAsync();
        Task AddAsync(Company details);
        Task Update(Company details);
        Task DeleteAsync(Company details);
    }
}
