﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MY
{
    public class Company
    { 
        public long CompanyId { get; private set; }
        public string CompanyName { get; private set; }
        public int Industry { get; private set; }
        public int NoOfEmployee { get; private set; }
        public string City { get; private set; }
        public long? ParentCompanyId { get; private set; }
        public bool IsActive { get; private set; }


        private Company(long companyId, string companyName, int industry, int noOfEmployee, string city, long? parentCompanyId, bool isActive)
        {
            CompanyId = companyId;
            CompanyName = companyName;
            Industry = industry;
            NoOfEmployee = noOfEmployee;
            City = city;
            ParentCompanyId = parentCompanyId;
            IsActive = isActive;
        }

        private Company(string companyName, int industry, int noOfEmployee, string city, long? parentCompanyId, bool isActive)
        {
            CompanyName = companyName;
            Industry = industry;
            NoOfEmployee = noOfEmployee;
            City = city;
            ParentCompanyId = parentCompanyId;
            IsActive = isActive;
        }

        public static Company AddCompany(string companyName, int industry, int noOfEmployee, string city, long? parentCompanyId)
        {
            return new Company(companyName, industry, noOfEmployee, city, parentCompanyId, true);
        }

        public void Update(string companyName, int industry, int noOfEmployee, string city, long? parentCompanyId)
        {
            CompanyName = companyName;
            Industry = industry;
            NoOfEmployee = noOfEmployee;
            City = city;
            ParentCompanyId = parentCompanyId;
        }

        public void Remove()
        {
            IsActive = false;
        }

    }
}
