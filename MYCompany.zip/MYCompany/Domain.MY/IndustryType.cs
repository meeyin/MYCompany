﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MY
{
    public class IndustryType
    {
        public int IndustryTypeId { get; private set; }
        public string IndustryTypeDescription { get; private set; }
        public bool IsActive { get; private set; }

        private IndustryType() { }

        private IndustryType(int industryTypeId, string industryTypeDescription, bool isActive)
        {
            IndustryTypeId = industryTypeId;
            IndustryTypeDescription = industryTypeDescription;
            IsActive = isActive;
           
        }

        #region Seed Data
        public static IndustryType CreateSeedData(int industryTypeId, string industryTypeDescription, bool isActive)
        {
            return new IndustryType(industryTypeId, industryTypeDescription, isActive);
        }
        #endregion

    }
}

