﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.MY
{
    public interface ICompanyChecker
    {
        public bool IsValidCompanyName(string companyName, long companyId);
        public bool IsParentCompanyValid(long? companyId);
        public bool IsIndustryValid(int industryId);
    }
}
