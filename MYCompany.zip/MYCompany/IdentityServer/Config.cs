﻿using IdentityServer4;
using IdentityServer4.Models;
using System.Collections.Generic;

namespace IdentityServer
{
    public class Config
    {
        public static IEnumerable<Client> Clients =>
            new Client[]
            {
                   new Client
                   {
                       ClientId = "companyApi",
                       ClientName = "Company API",
                       AllowedGrantTypes = {GrantType.AuthorizationCode},
                       RequirePkce = true,
                       RedirectUris = new List<string>()
                       {
                            "https://localhost:7186/swagger/oauth2-redirect.html",
                           "https://localhost:44387/swagger/oauth2-redirect.html"

                       },
                       PostLogoutRedirectUris = new List<string>()
                       {
                           "https://localhost:7186/signout-callback-oidc"
                       },

                       AllowedScopes = new List<string>
                       {
                           IdentityServerConstants.StandardScopes.OpenId,
                           IdentityServerConstants.StandardScopes.Profile,
                           IdentityServerConstants.StandardScopes.Address,
                           IdentityServerConstants.StandardScopes.Email,"companyApi",
                           "roles",
                           IdentityServerConstants.StandardScopes.OfflineAccess
                       },
                       AllowOfflineAccess = true,
                       RefreshTokenUsage = TokenUsage.OneTimeOnly,
                       AccessTokenLifetime = 6000,
                       RefreshTokenExpiration = TokenExpiration.Absolute,
                       AbsoluteRefreshTokenLifetime = 30000,
                       AccessTokenType = AccessTokenType.Jwt,
                       RequireClientSecret = false
                   }
            };

        // permission for accessing the api
        public static IEnumerable<ApiScope> ApiScopes =>
           new ApiScope[]
           {
               new ApiScope(name: "companyApi",   displayName: "companyApi."),
             
           };

        // the name of resource
        public static IEnumerable<ApiResource> ApiResources =>
          new ApiResource[]
          {
               new ApiResource("companyApi", "company API")
               {
                   Scopes = { "company.read", "company.write" }
               }
          };

        public static IEnumerable<IdentityResource> IdentityResources =>
          new IdentityResource[]
          {
              new IdentityResources.OpenId(),
              new IdentityResources.Profile(),
              new IdentityResources.Address(),
              new IdentityResources.Email(),
              new IdentityResource(
                    "roles",
                    "Your role(s)",
                    new List<string>() { "role" })
          };

     
    }
}
