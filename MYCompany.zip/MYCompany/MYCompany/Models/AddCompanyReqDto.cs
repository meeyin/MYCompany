﻿using System.ComponentModel.DataAnnotations;

namespace MYCompany.Models
{
    public class AddCompanyReqDto
    {
        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at most {1} characters long.")]
        public string CompanyName { get; set; }


        [Required(ErrorMessage = "The {0} field is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "The {0} must be greater than 0.")]
        public int Industry { get; set; }

        public int NoOfEmployee { get; set; }

        [StringLength(50, ErrorMessage = "The {0} must be at most {1} characters long.")]
        public string City { get; set; }


        public long? ParentCompanyId { get; set; }
    }
}
