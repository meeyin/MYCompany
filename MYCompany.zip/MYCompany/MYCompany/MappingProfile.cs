﻿using Application.MY.Command.Company;
using Application.MY.Query.Company;
using AutoMapper;
using MYCompany.Models;

namespace MYCompany
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<AddCompanyReqDto, AddCompanyCmd>();
            CreateMap<UpdCompanyReqDto, UpdCompanyCmd>();

            CreateMap<Domain.MY.Company, GetCompanyRespDto>();
            CreateMap<Domain.MY.Company, GetAllActiveCompanyRespDto>();

            CreateMap<Domain.MY.IndustryType, GetIndustryRespDto>();


        }
    }
}
