﻿using Application.MY.Query.Company;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace MYCompany.Controllers
{
    [Route("data")]
    public class DataController : Controller
    {
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public DataController(IMediator mediator, IMapper mapper)
        {
            _mediator = mediator;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("industry")]
        public async Task<IActionResult> Get()
        {
            var result = await _mediator.Send(new GetIndustryQuery());

            if (result.IsSuccess)
                return Ok(result.Value);
            else
                return BadRequest(result.Error);
        }
    }
}
