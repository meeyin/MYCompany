﻿using AutoMapper;
using MYCompany.Models;
using CSharpFunctionalExtensions;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using Application.MY.Query.Company;
using Application.MY.Command.Company;
using Domain.MY;

namespace MYCompany.Controllers
{
    [Route("company")]
    public class CompanyController : ControllerBase
    {

        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public CompanyController(IMediator mediator, IMapper mapper)
        {
            _mediator = mediator;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("list")]
        public async Task<IActionResult> Get([FromQuery] DataTableParameters param)
        {

            var result = await _mediator.Send(new GetCompanyQuery(param.Start,param.Length,param.ColumnSorting,param.Ordering,
                param.SearchParam,param.SearchValue));

            if (result.IsSuccess)
            {
                return Ok(result.Value);
            }
               
            else
                return BadRequest(result.Error);
        }

        [HttpGet]
        [Route("active-list")]
        public async Task<IActionResult> GetAllActiveCompany()
        {

            var result = await _mediator.Send(new GetAllActiveCompanyQuery());

            if (result.IsSuccess)
            {
                return Ok(result.Value);
            }

            else
                return BadRequest(result.Error);
        }

        [HttpGet]
        public async Task<IActionResult> Get(long companyId)
        {
            var result = await _mediator.Send(new GetCompanyByIdQuery(companyId));

            if (result.IsSuccess)
                return Ok(result.Value);
            else
                return BadRequest(result.Error);
        }


        [HttpPost]
        public async Task<IActionResult> AddCompany([FromBody] AddCompanyReqDto request)
        {

            var validationResults = new List<ValidationResult>();
            bool isValid = Validator.TryValidateObject(request, new ValidationContext(request), validationResults, true);

            // Output validation results
            if (isValid)
            {
                var cmd = _mapper.Map<AddCompanyCmd>(request);
                var result = await _mediator.Send(cmd);

                if (result.IsSuccess)
                    return Ok(result.Value);
                else
                    return BadRequest(result.Error);
            }
            else
            {
                string message = "";
                foreach (var validationResult in validationResults)
                {
                    message += validationResult + "  ";
                }

                return BadRequest(message);
            }

        }

        [HttpPut]
        public async Task<IActionResult> UpdCompany([FromBody] UpdCompanyReqDto request)
        {
            var validationResults = new List<ValidationResult>();
            bool isValid = Validator.TryValidateObject(request, new ValidationContext(request), validationResults, true);

            // Output validation results
            if (isValid)
            {
                var cmd = _mapper.Map<UpdCompanyCmd>(request);
                var result = await _mediator.Send(cmd);

                if (result.IsSuccess)
                    return Ok(result.Value);
                else
                    return BadRequest(result.Error);
            }
            else
            {
                string message = "";
                foreach (var validationResult in validationResults)
                {
                    message += validationResult +"  ";
                }

                return BadRequest(message);
            }

        }

        [HttpDelete]
        public async Task<IActionResult> DeleteCompany(long companyId)
        {
            var cmd = _mapper.Map<DeleteCompanyCmd>(companyId);
            var result = await _mediator.Send(cmd);

            if (result.IsSuccess)
                return Ok(result.Value);
            else
                return BadRequest(result.Error);

        }
    }

    public class DataTableParameters
    {
        public int Start { get; set; }
        public int Length { get; set; }
        public MerchantListingSorting? ColumnSorting { get; set; }
        public string Ordering { get; set; }
        public MerchantListingSearchParam? SearchParam { get; set; }
        public string SearchValue { get; set; }
    }
}
